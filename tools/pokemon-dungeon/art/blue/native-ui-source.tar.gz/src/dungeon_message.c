#include "global.h"
#include "globaldata.h"
#include "dungeon_message.h"
#include "dungeon_message_log.h"
#include "structs/dungeon_entity.h"
#include "bg_palette_buffer.h"
#include "graphics_memory.h"
#include "code_800D090.h"
#include "effect_main.h"
#include "dungeon_vram.h"
#include "dungeon_tilemap.h"
#include "dungeon_info.h"
#include "dungeon_range.h"
#include "dungeon_map.h"
#include "dungeon_main.h"
#include "dungeon_music.h"
#include "dungeon_util.h"
#include "exclusive_pokemon.h"
#include "file_system.h"
#include "input.h"
#include "menu_input.h"
#include "pokemon.h"
#include "sprite.h"
#include "string_format.h"
#include "text_1.h"
#include "text_2.h"
#include "text_3.h"
#include "dungeon_strings.h"
#include "dungeon_cutscene.h"
#include "dungeon_portrait_placement.h"

static EWRAM_DATA Entity *sLastLogMsgEntity = NULL;
static UNUSED EWRAM_DATA u8 sUnused = 0;
static EWRAM_DATA SpriteOAM sUnknown_202F1F0 = {0};
EWRAM_INIT bool8 gUnknown_203B434 = TRUE;

static bool8 sub_8052DC0(Entity *);
static void DisplayMessageAddToLog_Async(Entity *pokemon, const u8 *str, bool8 r2);

void sub_80521D0(void)
{
    s32 i;

    for (i = 0; i < UNK_1BBD4_STR_COUNT; i++) {
        gDungeon->unk1BDD4.unk1C054[i] = 0;
    }
    sLastLogMsgEntity = NULL;
    gUnknown_203B434 = TRUE;
    sub_8052210(FALSE);
}

void sub_8052210(bool8 a0)
{
    s32 i;

    for (i = 0; i < UNK_1BBD4_STR_COUNT; i++) {
        InlineStrcpy(gDungeon->unk1BDD4.unk0[i], "");
    }
    gDungeon->unk1BDD4.unk1C05F = 0;
    gDungeon->unk1BDD4.unk1C060 = 0;
    gDungeon->unk1BDD4.unk1C062 = 0;
    gDungeon->unk1BDD4.unk1C064 = 0;
    gDungeon->unk1BDD4.unk1C066 = 4;
    gDungeon->unk1BDD4.unk1C06C = 0;

    if (a0 && gUnknown_202EDD0 == 3) {
        sub_803EAF0(0, NULL);
        DungeonRunFrameActions(11);
    }
}

void sub_805229C(void)
{
    return sub_80526D0(0x50);
}

void LogMessageByIdWithPopupCheckUser_Async(Entity *pokemon, const u8 *str)
{
    if (ShouldDisplayEntity(pokemon)){
        DisplayMessageAddToLog_Async(pokemon, str, TRUE);
    }
}

UNUSED void TryDisplayDungeonLoggableMessage2_Async(Entity *pokemon, const u8 *str)
{
    if (ShouldDisplayEntity(pokemon)){
        DisplayMessageAddToLog_Async(pokemon, str, FALSE);
    }
}

void DisplayDungeonLoggableMessageFalse_Async(Entity *pokemon, const u8 *str)
{
    DisplayMessageAddToLog_Async(pokemon, str, FALSE);
}

void TryDisplayDungeonLoggableMessage3_Async(Entity *attacker, Entity *target, const u8 *str)
{
    u8 flag;
    flag = ShouldDisplayEntity(attacker) ? TRUE : FALSE;
    if(sub_8052DC0(target) != 0)
    {
        flag = TRUE;
    }
    if(flag)
    {
        DisplayMessageAddToLog_Async(attacker, str, TRUE);
    }
}

void TryDisplayDungeonLoggableMessage4_Async(Entity *attacker, Entity *target, const u8 *str)
{
    u8 flag;
    flag = ShouldDisplayEntity(attacker) ? TRUE : FALSE;
    if(sub_8052DC0(target) != 0)
    {
        flag = TRUE;
    }
    if(flag)
    {
        DisplayMessageAddToLog_Async(attacker, str, FALSE);
    }
}

void LogMessageByIdWithPopupCheckUserUnknown_Async(Entity *pokemon, DungeonPos *pos, const u8 *str)
{
    u8 flag;
    flag = ShouldDisplayEntity(pokemon) ? TRUE : FALSE;
    if(sub_803F428(pos))
    {
        flag = TRUE;
    }
    if(flag)
    {
        DisplayMessageAddToLog_Async(pokemon, str, TRUE);
    }
}

void DisplayDungeonLoggableMessageTrue_Async(Entity *pokemon, const u8 *str)
{
    DisplayMessageAddToLog_Async(pokemon, str, TRUE);
}

static void DisplayMessageAddToLog_Async(Entity *pokemon, const u8 *str, bool8 r2)
{
    u8 txt[64];
    bool8 r7;
    bool32 r8, r9;

    if (sLastLogMsgEntity != pokemon) {
        r7 = TRUE;
    }
    else {
        r7 = gUnknown_203B434;
    }

    r8 = 1;
    sLastLogMsgEntity = pokemon;
    gUnknown_203B434 = FALSE;
    r9 = FALSE;
    while (TRUE) {
        while (TRUE) {
            s32 val = gDungeon->unk1BDD4.unk1C060;
            if (++val == UNK_1BBD4_STR_COUNT) {
                val = 0;
            }

            if (val != gDungeon->unk1BDD4.unk1C062) {
                break;
            }
            DungeonRunFrameActions(0);
        }

        if (*str == '\0')
            break;

        gDungeon->unk1BDD4.unk1C054[gDungeon->unk1BDD4.unk1C060] = r7;
        str = FormatString(str, txt, txt + 62, 128);
        if (*str == '\r') str++;
        if (*str == '\n') str++;
        CopyStringToMessageLog(txt, r7, r8);
        r7 = 0;
        r8 = 0;
        if (r2) {
            r9 = TRUE;
            InlineStrncpy(gDungeon->unk1BDD4.unk0[gDungeon->unk1BDD4.unk1C060], txt, 64);
            if (++gDungeon->unk1BDD4.unk1C060 == UNK_1BBD4_STR_COUNT) {
                gDungeon->unk1BDD4.unk1C060 = 0;
            }
        }
    }

    if (r9) {
        gDungeon->unk1BDD4.unk1C064 = 240;
        if (gDungeon->unk1BDD4.unk1C06C == 0) {
            gDungeon->unk1BDD4.unk1C06C = 1;
        }
        sub_805E804();
    }
}

void xxx_draw_string_80524F0(void)
{
    struct UnkStructDungeon1BDD4 *strPtr = &gDungeon->unk1BDD4;

    switch (strPtr->unk1C06C) {
        case 0:
            break;
        case 1:
            if (sub_800EC74())
                break;
            sub_803EAF0(3, NULL);
        // fall through
        case 2: {
            UnkDrawStringStruct sp;
            u32 currChr;

            s32 id = strPtr->unk1C062;
            if (id == strPtr->unk1C060) {
                strPtr->unk1C06C = 0;
            }
            else {
                const u8 *txtPtr = strPtr->unk0[id];

                sp.x = 4;
                sp.y = strPtr->unk1C066;
                sp.unk10 = 7;
                sub_80073B8(0);
                if (strPtr->unk1C054[id] != 0 && strPtr->unk1C066 >= 8) {
                    AddDoubleUnderScoreHighlight(0, 0, strPtr->unk1C066 - 1, 0xE0, 7);
                }

                while (TRUE) {
                    txtPtr = HandleSpecialCharFormat(txtPtr, &sp);
                    if (*txtPtr == '\0' || *txtPtr == '\r' || *txtPtr == '\n')
                        break;
                    txtPtr = GetNextCharFromStr(txtPtr, &currChr);
                    if (currChr == '`') {
                        sp.x += 6;
                    }
                    else {
                        sp.x += DrawCharOnWindow(sp.x, sp.y, currChr, sp.unk10, 0);
                    }
                }
                sub_80073E0(0);
                strPtr->unk1C064 = 240;
                if (++id == UNK_1BBD4_STR_COUNT) {
                    id = 0;
                }
                strPtr->unk1C062 = id;
                strPtr->unk1C066 += 11;
                if (strPtr->unk1C066 >= 48) {
                    strPtr->unk1C066 = 37;
                    strPtr->unk1C068 = 0;
                    strPtr->unk1C06C = 3;
                }
            }
            break;
        }
    case 3:
        strPtr->unk1C068++;
        gIwramTextFunc4(0);
        if (strPtr->unk1C068 > 10) {
            strPtr->unk1C06C = 2;
        }
        break;
    }

    if (strPtr->unk1C05E == 0 && strPtr->unk1C064 != 0 && --strPtr->unk1C064 == 0) {
        strPtr->unk1C06C = 0;
        sub_803EAF0(0, NULL);
        sub_8052210(FALSE);
    }
}

void sub_80526D0(s32 r0)
{
    struct UnkStructDungeon1BDD4 *strPtr = &gDungeon->unk1BDD4;
    while (strPtr->unk1C06C != 0 || gDungeon->unk1BDD4.unk1C060 != gDungeon->unk1BDD4.unk1C062) {
        DungeonRunFrameActions(r0);
    }
}

void sub_8052740(s32 a0)
{
    s32 i;
    struct UnkStructDungeon1BDD4 *strPtr = &gDungeon->unk1BDD4;

    sub_80526D0(a0);
    for (i = 0; i < 240; i++) {
        if (strPtr->unk1C064 < 180)
            break;
        if ((gRealInputs.held & AB_BUTTONS) == AB_BUTTONS)
            break;
        if (gRealInputs.pressed & JOY_EXCL_DPAD)
            break;
        DungeonRunFrameActions(a0);
    }
}

// Prints string in dialogue box and waits for A/B button press
#define PRINT_STRING_WAIT_PRESS_ASYNC(chosenMenuIndex)   \
{                                           \
    s32 unkPrintRet;                        \
                                            \
    do {                                    \
        DrawDialogueBoxString_Async();            \
        DungeonRunFrameActions(9);                     \
        unkPrintRet = sub_80144A4(chosenMenuIndex);\
    } while (unkPrintRet != 0);             \
}

void DisplayDungeonMessage_Async(struct MonDialogueSpriteInfo *monSpriteInfo, const u8 *str, bool8 a2)
{
    MonPortraitMsg monPortrait, *monPortraitPtr;
    s32 chosenMenuIndex;

    if (gUnknown_203B40C) {
        sub_8052740(10);
    }

    sub_803EAF0(2, NULL);
    sub_8052210(FALSE);

    monPortraitPtr = NULL;
    monPortrait.faceFile = NULL;
    monPortrait.faceData = NULL;
    if (!gDungeon->unk181e8.blinded
        && !gDungeon->unk181e8.hallucinating
        && monSpriteInfo != NULL
        && IsPokemonDialogueSpriteAvail(monSpriteInfo->species, monSpriteInfo->spriteId))
    {
        monPortrait.faceFile = GetDialogueSpriteDataPtr(monSpriteInfo->species);
        monPortrait.faceData = (PortraitGfx *) monPortrait.faceFile->data;
        monPortrait.pos.x = 2;
        monPortrait.pos.y = 9;
        monPortrait.spriteId = monSpriteInfo->spriteId;
        monPortrait.flip = FALSE;
        monPortrait.unkE = 0;
        monPortraitPtr = &monPortrait;
    }

    CreateMenuDialogueBoxAndPortrait(str, 0, 0, NULL, NULL, 3, 0, monPortraitPtr, a2 ? 0x701 : 0x400);
    gDungeon->unk1BDD4.unk1C05F = 1;
    PRINT_STRING_WAIT_PRESS_ASYNC(&chosenMenuIndex);
    gDungeon->unk1BDD4.unk1C05F = 0;

    TRY_CLOSE_FILE(monPortrait.faceFile);

    if (a2) {
        sub_805E804();
        LoadDungeonMapPalette();
        if (gShowDungeonMap) {
            sub_803EAF0(0, NULL);
        }
        else {
            sub_803EAF0(1, NULL);
        }
    }

    DungeonWaitFrames_Async(8, 9);
}

void DisplayDungeonLoggableMessage(Entity *pokemon, const u8 *str)
{
    DisplayDungeonMessage_Async(NULL, str, TRUE);
    DisplayDungeonLoggableMessageFalse_Async(pokemon, str);
}

static const u16 sUnknownDialogueFlags[] = {0x30D, 0x10D, 0x30D, 0x10D, 0x301, 1, 0x11};

void DisplayDungeonDialogue_Async(const struct DungeonDialogueStruct *dialogueInfo)
{
    MonPortraitMsg monPortrait;
    s32 leaderId, partnerId, dialogueMonId;
    s32 chosenMenuIndex;
    Entity *leader = CutsceneGetLeader();
    Entity *partner = CutsceneGetPartner();
    MonPortraitMsg *monPortraitPtr = NULL;

    if (leader != NULL) {
        EntityInfo *leaderInfo = GetEntInfo(leader);
        DungeonMon *monStruct2 = &gRecruitedPokemonRef->dungeonTeam[leaderInfo->teamIndex];

        sub_808DA0C(gFormatBuffer_Monsters[0], monStruct2);
        leaderId = leaderInfo->apparentID;
    }
    else {
        leaderId = MONSTER_NONE;
        InlineStrcpy(gFormatBuffer_Monsters[0], "??");
    }

    if (partner != NULL) {
        EntityInfo *partnerInfo = GetEntInfo(partner);
        DungeonMon *monStruct2 = &gRecruitedPokemonRef->dungeonTeam[partnerInfo->teamIndex];

        sub_808DA0C(gFormatBuffer_Monsters[1], monStruct2);
        partnerId = partnerInfo->apparentID;
    }
    else {
        partnerId = MONSTER_NONE;
        InlineStrcpy(gFormatBuffer_Monsters[1], "??");
    }

    switch (dialogueInfo->speciesId) {
        case DIALOGUE_MONSTER_PLAYER:
            dialogueMonId = leaderId;
            sprintfStatic(gSpeakerNameBuffer, _("{COLOR YELLOW}%s{RESET}"), gFormatBuffer_Monsters);
            break;
        case DIALOGUE_MONSTER_PARTNER:
            dialogueMonId = partnerId;
            sprintfStatic(gSpeakerNameBuffer, _("{COLOR YELLOW}%s{RESET}"), gFormatBuffer_Monsters[1]);
            break;
        case DIALOGUE_MONSTER_NONE:
            dialogueMonId = MONSTER_NONE;
            InlineStrcpy(gSpeakerNameBuffer, _("{COLOR YELLOW}{SPEECH_BUBBLE}{RESET}"));
            break;
        default:
            dialogueMonId = dialogueInfo->speciesId;
            CopyYellowMonsterNametoBuffer(gSpeakerNameBuffer, dialogueMonId);
            break;
    }

    if (dialogueInfo->type == 2 || dialogueInfo->type == 3) {
        InlineStrcpy(gSpeakerNameBuffer, _("{COLOR YELLOW}{SPEECH_BUBBLE}{RESET}"));
    }

    while (TRUE) {
        if (dialogueInfo->allowType == DIALOGUE_ALLOW_ALL)
            break;
        if (dialogueInfo->allowType == DIALOGUE_ONLY_SQUIRTLE_TOTODILE   && (dialogueMonId == MONSTER_SQUIRTLE || dialogueMonId == MONSTER_TOTODILE))
            break;
        if (dialogueInfo->allowType == DIALOGUE_ALLOW_MOST               && (dialogueMonId == MONSTER_BULBASAUR || dialogueMonId == MONSTER_CYNDAQUIL || dialogueMonId == MONSTER_MUDKIP || dialogueMonId == MONSTER_PIKACHU || dialogueMonId == MONSTER_CHARMANDER || dialogueMonId == MONSTER_TREECKO))
            break;
        if (dialogueInfo->allowType == DIALOGUE_ONLY_TORCHIC_CHICORITA   && (dialogueMonId == MONSTER_TORCHIC || dialogueMonId == MONSTER_CHIKORITA))
            break;
        dialogueInfo++;
    }

    if (!gDungeon->unk181e8.blinded
        && !gDungeon->unk181e8.hallucinating
        && dialogueInfo->type != 4
        && dialogueInfo->spriteId != 0x80
        && dialogueMonId != MONSTER_NONE)
    {
        const PortraitPlacementInfo *placementInfo = GetPortraitPlacementInfo(dialogueInfo->spritePlacementId);

        monPortraitPtr = &monPortrait;
        monPortraitPtr->faceFile = GetDialogueSpriteDataPtr(dialogueMonId);
        if (monPortraitPtr->faceFile != NULL) {
            monPortraitPtr->faceData = (PortraitGfx *) monPortraitPtr->faceFile->data;
            monPortraitPtr->unkE = 0;
            monPortraitPtr->spriteId = dialogueInfo->spriteId;
            monPortraitPtr->flip = placementInfo->flip;
            monPortraitPtr->pos.x = placementInfo->pos.x;
            monPortraitPtr->pos.y = placementInfo->pos.y;
            if (monPortraitPtr->pos.y < 2) {
                monPortraitPtr->pos.y = 2;
            }
        }
        else {
            monPortraitPtr = NULL;
        }
    }

    sub_8052740(10);
    sub_803EAF0(2, NULL);
    sub_8052210(FALSE);
    CreateDialogueBoxAndPortrait(dialogueInfo->str, 0, monPortraitPtr, sUnknownDialogueFlags[dialogueInfo->type]);
    PRINT_STRING_WAIT_PRESS_ASYNC(&chosenMenuIndex);

    if (monPortraitPtr != NULL) {
        CloseFile(monPortraitPtr->faceFile);
    }

    if (dialogueInfo->type != 1 && dialogueInfo->type != 3) {
        LoadDungeonMapPalette();
        sub_803EAF0(0, NULL);
    }
    DungeonWaitFrames_Async(8, 9);
}

bool32 DisplayDungeonYesNoMessage_Async(struct MonDialogueSpriteInfo *monSpriteInfo, const u8 *str, bool32 defaultYes)
{
    MonPortraitMsg monPortrait, *monPortraitPtr;
    s32 chosenMenuIndex;

    sub_8052740(10);
    sub_803EAF0(2, NULL);
    sub_8052210(FALSE);

    monPortraitPtr = NULL;
    monPortrait.faceFile = NULL;
    monPortrait.faceData = NULL;
    if (!gDungeon->unk181e8.blinded
        && !gDungeon->unk181e8.hallucinating
        && monSpriteInfo != NULL
        && IsPokemonDialogueSpriteAvail(monSpriteInfo->species, monSpriteInfo->spriteId))
    {
        monPortrait.faceFile = GetDialogueSpriteDataPtr(monSpriteInfo->species);
        monPortrait.faceData = (PortraitGfx *) monPortrait.faceFile->data;
        monPortrait.pos.x = 2;
        monPortrait.pos.y = 9;
        monPortrait.spriteId = monSpriteInfo->spriteId;
        monPortrait.flip = FALSE;
        monPortrait.unkE = 0;
        monPortraitPtr = &monPortrait;
    }

    if (defaultYes == TRUE) {
        CreateYesNoDialogueBoxAndPortrait_DefaultYes(str, monPortraitPtr, 0x300); // Yes/No - cursor starts at Yes
    }
    else {
        CreateYesNoDialogueBoxAndPortrait_DefaultNo(str, monPortraitPtr, 0x300); // Yes/No - cursor starts at NO
    }

    PRINT_STRING_WAIT_PRESS_ASYNC(&chosenMenuIndex);

    TRY_CLOSE_FILE(monPortrait.faceFile);

    LoadDungeonMapPalette();
    sub_803EAF0(0, NULL);

    if (chosenMenuIndex == 1)
        return TRUE;
    else
        return FALSE;
}

s32 DisplayDungeonMenuMessage(struct MonDialogueSpriteInfo *monSpriteInfo, const u8 *str, const MenuItem *menuItems, u16 unkArg)
{
    MonPortraitMsg monPortrait, *monPortraitPtr;
    s32 chosenMenuIndex;

    sub_8052740(10);
    sub_803EAF0(2, NULL);
    sub_8052210(FALSE);

    monPortraitPtr = NULL;
    monPortrait.faceFile = NULL;
    monPortrait.faceData = NULL;
    if (!gDungeon->unk181e8.blinded
        && !gDungeon->unk181e8.hallucinating
        && monSpriteInfo != NULL
        && IsPokemonDialogueSpriteAvail(monSpriteInfo->species, monSpriteInfo->spriteId))
    {
        monPortrait.faceFile = GetDialogueSpriteDataPtr(monSpriteInfo->species);
        monPortrait.faceData = (PortraitGfx *) monPortrait.faceFile->data;
        monPortrait.pos.x = 2;
        monPortrait.pos.y = 9;
        monPortrait.spriteId = monSpriteInfo->spriteId;
        monPortrait.flip = FALSE;
        monPortrait.unkE = 0;
        monPortraitPtr = &monPortrait;
    }

    CreateMenuDialogueBoxAndPortrait(str, 0, -1, menuItems, NULL, 3, 0, monPortraitPtr, unkArg);
    PRINT_STRING_WAIT_PRESS_ASYNC(&chosenMenuIndex);

    TRY_CLOSE_FILE(monPortrait.faceFile);

    LoadDungeonMapPalette();
    sub_803EAF0(0, NULL);
    return chosenMenuIndex;
}

void BufferCutsceneProtagonists(s16 destIDs[2], Entity *leader, Entity *partner)
{
    if (EntityIsValid(leader)) {
        SubstitutePlaceholderStringTags(gFormatBuffer_Monsters[0], leader, COLOR_WHITE);
        destIDs[0] = GetEntInfo(leader)->apparentID;
    }
    else {
        InlineStrcpy(gFormatBuffer_Monsters[0], "??");
        destIDs[0] = 0;
    }

    if (EntityIsValid(partner)) {
        SubstitutePlaceholderStringTags(gFormatBuffer_Monsters[1], partner, COLOR_WHITE);
        destIDs[1] = GetEntInfo(partner)->apparentID;
    }
    else {
        InlineStrcpy(gFormatBuffer_Monsters[1], "??");
        destIDs[1] = 0;
    }
}

static bool8 sub_8052DC0(Entity *entity)
{
    return ShouldDisplayEntity(entity);
}

static inline bool32 DisplayTutorialMsg(Entity *leader, const TutorialFlagMsg *tutorial, bool32 unkFunctionCall)
{
    const u8 *str;
    s32 flag = tutorial->flagId;
    bool8 flagDone = GetTutorialFlag(flag);

    if (!flagDone) {
        SetTutorialFlag(flag);
        sub_8083E28();
        str = tutorial->str;
        DisplayDungeonMessage_Async(NULL, str, TRUE);
        if (unkFunctionCall) {
            DisplayDungeonLoggableMessageFalse_Async(leader, str);
        }
        return TRUE;
    }
    return FALSE;
}

void TryDisplayGeneralTutorialMessage(void)
{
    Entity *leader = GetLeader();

    if (DisplayTutorialMsg(leader, &gUnknown_80FF020, TRUE)) return;
    if (DisplayTutorialMsg(leader, &gUnknown_80FF080, TRUE)) return;
    if (DisplayTutorialMsg(leader, &gUnknown_80FF0D8, TRUE)) return;
    if (gDungeon->unk644.dungeonLocation.id == DUNGEON_THUNDERWAVE_CAVE) {
        if (DisplayTutorialMsg(leader, &gUnknown_80FF13C, TRUE)) return;
        if (DisplayTutorialMsg(leader, &gUnknown_80FF1B4, TRUE)) return;
        if (DisplayTutorialMsg(leader, &gMovementTutorial, TRUE)) return;
        if (DisplayTutorialMsg(leader, &gHungerTutorial, TRUE)) return;
    }
}

void DisplayItemTip(u8 itemId)
{
    u32 itemCategory = GetItemCategory(itemId);

    if (itemCategory == CATEGORY_FOOD_GUMMIES) {
        DisplayTutorialMsg(NULL, &gFoodTutorial, FALSE);
    }
    else if (itemId == ITEM_ORAN_BERRY) {
        DisplayTutorialMsg(NULL, &gOranTutorial, FALSE);
    }
    else if (itemId == ITEM_CHERI_BERRY) {
        DisplayTutorialMsg(NULL, &gCheriTutorial, FALSE);
    }
    else if (itemId == ITEM_BLAST_SEED) {
        DisplayTutorialMsg(NULL, &gBlastSeedTutorial, FALSE);
    }
    else if (itemId == ITEM_GRAVELEROCK) {
        DisplayTutorialMsg(NULL, &gUnknown_80FF4A0, FALSE);
    }
    else if (itemId == ITEM_PECHA_BERRY) {
        DisplayTutorialMsg(NULL, &gPechaTutorial, FALSE);
    }
    else if (itemId == ITEM_SLEEP_SEED) {
        DisplayTutorialMsg(NULL, &gSleepSeedTutorial, FALSE);
    }
    else if (itemId == ITEM_POKE) {
        DisplayTutorialMsg(NULL, &gMoneyTutorial, FALSE);
    }
}

void DisplayYouReachedDestFloorStr(void)
{
    if (gDungeon->unkA != 0) {
        DisplayDungeonMessage_Async(NULL, gUnknown_80FF6F8, 1); // But the pokemon you seek isn't here...
    }
    else {
        DisplayDungeonMessage_Async(NULL, gUnknown_80FF6A4, 1);
    }
}

// Used only for displaying Frosy Forest's text at floor 6
void sub_8052FB8(const u8 *str)
{
    s32 r8 = 0, r9, j;
    {
        s32 i;
        for (i = 1; i < 30; i++) {
            gBgTilemaps[0][0][i] = 0;
        }
    }

    CreateMenuDialogueBoxAndPortrait(str, 0, 0, NULL, NULL, 2, 0, NULL, 0x30);
    r9 = 0;
    while (TRUE) {
        if (r8 < 62) {
            r8++;
            for (j = 0; j < 8; j++) {
                SetBGPaletteBufferColorRGB(240 + j, &gFontPalette[j], r8 / 2, NULL);
            }
        }
        else {
            r9++;
            if (r9 & 8) {
                SpriteSetAffine1(&sUnknown_202F1F0, 0);
                SpriteSetAffine2(&sUnknown_202F1F0, 0);
                SpriteSetObjMode(&sUnknown_202F1F0, 0);
                SpriteSetMosaic(&sUnknown_202F1F0, 0);
                SpriteSetBpp(&sUnknown_202F1F0, 0);
                SpriteSetShape(&sUnknown_202F1F0, 1);
                SpriteSetTileNum(&sUnknown_202F1F0, 0x3F0);
                SpriteSetPriority(&sUnknown_202F1F0, 0);
                SpriteSetPalNum(&sUnknown_202F1F0, 15);
                SpriteSetY(&sUnknown_202F1F0, 120);
                SpriteSetMatrixNum(&sUnknown_202F1F0, 0);
                SpriteSetSize(&sUnknown_202F1F0, 0);
                SpriteSetX(&sUnknown_202F1F0, 112);

                AddSprite(&sUnknown_202F1F0, 0x100, NULL, NULL);
            }
            if (gRealInputs.pressed & AB_BUTTONS)
                break;
        }
        DrawDialogueBoxString_Async();
        DungeonRunFrameActions(9);
    }

    while (r8 >= 0) {
        for (j = 0; j < 8; j++) {
            SetBGPaletteBufferColorRGB(240 + j, &gFontPalette[j], r8 / 2, NULL);
        }
        DrawDialogueBoxString_Async();
        DungeonRunFrameActions(9);
        r8--;
    }

    ShowWindows(NULL, TRUE, TRUE);
    DungeonRunFrameActions(9);
    LoadDungeonMapPalette();
    for (j = 0; j < 8; j++) {
        SetBGPaletteBufferColorArray(240 + j, &gFontPalette[j]);
    }
    DungeonWaitFrames_Async(8, 9);
}

const u8 *GetCurrentDungeonName(void)
{
    if (gDungeon->unk644.missionKind == DUNGEON_MISSION_OUTONRESCUE) {
        return GetDungeonName1(DUNGEON_OUT_ON_RESCUE);
    }
    else {
        return GetDungeonName1(gDungeon->unk644.dungeonLocation.id);
    }
}
