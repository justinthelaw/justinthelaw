#include "global.h"
#include "decompress_sir.h"
#include "structs/axdata.h"
const struct EfoFileData gUnknown_97AA090;
const SiroArchive gUnknown_97A8C38 = { "SIRO", &gUnknown_97AA090 };
const ax_pose gUnknown_97A8C48[] = {
    { -1, { 0, 0 }, 485, 33007, 15360 },
    { -1, { 255, -1 }, 65535, 65535, 65535 },
};
const ax_pose gUnknown_97A8C5C[] = {
    { -1, { 0, 0 }, 485, 37105, 15360 },
    { -1, { 255, -1 }, 65535, 65535, 65535 },
};
const ax_pose gUnknown_97A8C70[] = {
    { -1, { 0, 0 }, 485, 32999, 15376 },
    { -1, { 0, 0 }, 33253, 33031, 15392 },
    { -1, { 0, 0 }, 16853, 33008, 15400 },
    { -1, { 0, 0 }, 461, 251, 15408 },
    { -1, { 255, -1 }, 65535, 65535, 65535 },
};
const ax_pose gUnknown_97A8CA2[] = {
    { -1, { 0, 0 }, 485, 37113, 15376 },
    { -1, { 0, 0 }, 33253, 37097, 15392 },
    { -1, { 0, 0 }, 16853, 37104, 15400 },
    { -1, { 0, 0 }, 461, 4349, 15408 },
    { -1, { 255, -1 }, 65535, 65535, 65535 },
};
const ax_pose gUnknown_97A8CD4[] = {
    { -1, { 0, 0 }, 485, 32998, 15409 },
    { -1, { 0, 0 }, 33253, 33030, 15425 },
    { -1, { 0, 0 }, 453, 33005, 15433 },
    { -1, { 0, 0 }, 33189, 33013, 15449 },
    { -1, { 0, 0 }, 33237, 269, 15457 },
    { -1, { 0, 0 }, 445, 261, 15459 },
    { -1, { 0, 0 }, 413, 253, 15459 },
    { -1, { 0, 0 }, 33255, 278, 15460 },
    { -1, { 255, -1 }, 65535, 65535, 65535 },
};
const ax_pose gUnknown_97A8D2E[] = {
    { -1, { 0, 0 }, 485, 37114, 15409 },
    { -1, { 0, 0 }, 33253, 37098, 15425 },
    { -1, { 0, 0 }, 453, 37107, 15433 },
    { -1, { 0, 0 }, 33189, 37115, 15449 },
    { -1, { 0, 0 }, 33237, 4331, 15457 },
    { -1, { 0, 0 }, 445, 4339, 15459 },
    { -1, { 0, 0 }, 413, 4347, 15459 },
    { -1, { 0, 0 }, 33255, 4322, 15460 },
    { -1, { 255, -1 }, 65535, 65535, 65535 },
};
const ax_pose gUnknown_97A8D88[] = {
    { -1, { 0, 0 }, 509, 4348, 3174 },
    { -1, { 255, -1 }, 65535, 65535, 65535 },
};
const ax_pose gUnknown_97A8D9C[] = {
    { -1, { 0, 0 }, 504, 17656, 27751 },
    { -1, { 255, -1 }, 65535, 65535, 65535 },
};
const ax_pose gUnknown_97A8DB0[] = {
    { -1, { 0, 0 }, 504, 17656, 27755 },
    { -1, { 255, -1 }, 65535, 65535, 65535 },
};
const ax_pose gUnknown_97A8DC4[] = {
    { -1, { 0, 0 }, 16891, 248, 19567 },
    { -1, { 255, -1 }, 65535, 65535, 65535 },
};
const ax_pose gUnknown_97A8DD8[] = {
    { -1, { 0, 0 }, 503, 16632, 19569 },
    { -1, { 255, -1 }, 65535, 65535, 65535 },
};
const ax_pose gUnknown_97A8DEC[] = {
    { -1, { 0, 0 }, 504, 16632, 19573 },
    { -1, { 255, -1 }, 65535, 65535, 65535 },
};
const ax_pose gUnknown_97A8E00[] = {
    { -1, { 0, 0 }, 505, 16632, 19577 },
    { -1, { 255, -1 }, 65535, 65535, 65535 },
};
UNUSED const u32 gUnknown_97A8E14 = 125;
const ax_anim gUnknown_97A8E18[] = {
    { 1,   0,   0, { 0, 0 }, { 0, 0 } },
    { 1,   0,   6, { 0, 0 }, { 0, 0 } },
    { 1,   0,   2, { 0, 0 }, { 0, 0 } },
    { 1,   0,   6, { 0, 0 }, { 0, 0 } },
    { 1,   0,   5, { 0, 0 }, { 0, 0 } },
    { 1,   0,   6, { 0, 0 }, { 0, 0 } },
    { 1,   0,   4, { 0, 0 }, { 0, 0 } },
    { 1,   0,   6, { 0, 0 }, { 0, 0 } },
    { 1,   0,   5, { 0, 0 }, { 0, 0 } },
    { 1,   0,   6, { 0, 0 }, { 0, 0 } },
    { 1,   0,   4, { 0, 0 }, { 0, 0 } },
    { 1,   0,   6, { 0, 0 }, { 0, 0 } },
    { 1,   0,   2, { 0, 0 }, { 0, 0 } },
    { 1,   0,   6, { 0, 0 }, { 0, 0 } },
    { 1,   0,   3, { 0, 0 }, { 0, 0 } },
    { 1,   0,   6, { 0, 0 }, { 0, 0 } },
    { 1,   0,   2, { 0, 0 }, { 0, 0 } },
    { 1,   0,   6, { 0, 0 }, { 0, 0 } },
    { 1,   0,   3, { 0, 0 }, { 0, 0 } },
    { 1,   0,   6, { 0, 0 }, { 0, 0 } },
    { 1,   0,   0, { 0, 0 }, { 0, 0 } },
    { 1,   0,   6, { 0, 0 }, { 0, 0 } },
    { 1,   0,   1, { 0, 0 }, { 0, 0 } },
    { 1,   0,   6, { 0, 0 }, { 0, 0 } },
    { 1,   0,   0, { 0, 0 }, { 0, 0 } },
    { 1,   0,   6, { 0, 0 }, { 0, 0 } },
    { 1,   0,   1, { 0, 0 }, { 0, 0 } },
    { 0,   0,   0, { 0, 0 }, { 0, 0 } },
};
const ax_anim gUnknown_97A8F68[] = {
    { 4,   0,   7, { 0, 0 }, { 0, 0 } },
    { 4,   0,   8, { 0, 0 }, { 0, 0 } },
    { 0,   0,   0, { 0, 0 }, { 0, 0 } },
};
const ax_anim gUnknown_97A8F8C[] = {
    { 1,   0,   9, { -5, 3 }, { 0, 0 } },
    { 1,   0,   10, { -6, 5 }, { 0, 0 } },
    { 2,   0,   10, { -8, 7 }, { 0, 0 } },
    { 2,   0,   10, { -11, 9 }, { 0, 0 } },
    { 2,   0,   10, { -12, 10 }, { 0, 0 } },
    { 2,   0,   10, { -13, 11 }, { 0, 0 } },
    { 3,   0,   11, { -15, 9 }, { 0, 0 } },
    { 3,   0,   11, { -16, 9 }, { 0, 0 } },
    { 3,   0,   12, { -17, 7 }, { 0, 0 } },
    { 3,   0,   12, { -18, 6 }, { 0, 0 } },
    { 0,   0,   0, { 0, 0 }, { 0, 0 } },
};
const u32 gUnknown_97A9010[] = INCBIN_U32("data/effects/efob008.4bpp");
const RGB_Struct gUnknown_97A9FB0[] = INCBIN_U8("data/effects/efob008.pmdpal");
const ax_pose *const gUnknown_97A9FF0[] = {
    gUnknown_97A8C48,
    gUnknown_97A8C5C,
    gUnknown_97A8C70,
    gUnknown_97A8CA2,
    gUnknown_97A8CD4,
    gUnknown_97A8D2E,
    gUnknown_97A8D88,
    gUnknown_97A8D9C,
    gUnknown_97A8DB0,
    gUnknown_97A8DC4,
    gUnknown_97A8DD8,
    gUnknown_97A8DEC,
    gUnknown_97A8E00,
};
const ax_anim *const gUnknown_97AA024[] = {
    gUnknown_97A8E18,
    gUnknown_97A8E18,
    gUnknown_97A8E18,
    gUnknown_97A8E18,
    gUnknown_97A8E18,
    gUnknown_97A8E18,
    gUnknown_97A8E18,
    gUnknown_97A8E18,
};
const ax_anim *const gUnknown_97AA044[] = {
    gUnknown_97A8F68,
    gUnknown_97A8F68,
    gUnknown_97A8F68,
    gUnknown_97A8F68,
    gUnknown_97A8F68,
    gUnknown_97A8F68,
    gUnknown_97A8F68,
    gUnknown_97A8F68,
};
const ax_anim *const gUnknown_97AA064[] = {
    gUnknown_97A8F8C,
    gUnknown_97A8F8C,
    gUnknown_97A8F8C,
    gUnknown_97A8F8C,
    gUnknown_97A8F8C,
    gUnknown_97A8F8C,
    gUnknown_97A8F8C,
    gUnknown_97A8F8C,
};
const ax_anim *const *const gUnknown_97AA084[] = {
    gUnknown_97AA024,
    gUnknown_97AA044,
    gUnknown_97AA064,
};
const EfoFileData gUnknown_97AA090 = {
    gUnknown_97A9FF0,
    gUnknown_97AA084,
    ARRAY_COUNT(gUnknown_97AA084), // 3
    NULL,
    NULL,
    gUnknown_97A9010,
    gUnknown_97A9FB0,
    sizeof(gUnknown_97A9010) / 32, // 125
};
